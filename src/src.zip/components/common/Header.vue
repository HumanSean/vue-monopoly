<template>
  <div>
    <h1>Vue 大 富 翁</h1>
    <el-button-group>
      <el-button type="primary">
        <i class="el-icon-user"></i>
      </el-button>
      <el-button type="primary">
        <i class="el-icon-setting"></i>
      </el-button>
    </el-button-group>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>