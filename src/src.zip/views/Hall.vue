<template>
    <div>
        <Header></Header>
    </div>
</template>

<script>
    import Header from '@/components/common/Header.vue';
    export default {
        components: {
            Header,
        },
    }
</script>

<style lang="scss" scoped>

</style>