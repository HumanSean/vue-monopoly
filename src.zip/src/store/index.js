import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    // config: {},
    // players: [],
    // map: [],
    // v: 800
  },
  mutations: {
    // setConfig(state, config) {
    //   state.config = config;
    // },
    // setPlayers(state, players) {
    //   state.players = players;
    // }
  },
  actions: {},
  modules: {}
});
